import sys
import math
from math import log10
import matplotlib.pyplot as plt
import numpy as np

def read_fasta(filepath):
    with open(filepath, "r") as f:
        lines = f.readlines()
    if not lines:
        raise ValueError("File is empty!")
    sequence_lines = []
    description = None
    for line in lines:
        line = line.strip()
        if line.startswith(">"):
            description = line
            continue
        sequence_lines.append(line)
    sequence = "".join(sequence_lines).upper()
    return description, sequence

def analyze_sequence(sequence):
    alphabet = {'A':0, 'G':0, 'C':0, 'T':0}
    total = 0
    for letter in sequence:
        if letter in alphabet:
            alphabet[letter] += 1
            total += 1
    print("Sequence length:", total)
    print(alphabet)
    for item in alphabet:
        freq = (alphabet[item] / total) * 100
        print(f'The relative frequency of {item} is {freq:.2f}%')

def calculate_tm(window, na_conc=0.05):
    g = window.count("G")
    c = window.count("C")
    gc_percent = (g + c) / len(window) * 100
    tm = 81.5 + 16.6 * log10(na_conc) + 0.41 * gc_percent - 600 / len(window)
    return tm

def sliding_window_tm(sequence, window_size=8):
    tm_values = []
    for i in range(len(sequence) - window_size + 1):
        window = sequence[i:i + window_size]
        tm = calculate_tm(window)
        tm_values.append((i+1, window, tm))
    return tm_values

def smooth(values, window_size=15):
    smoothed = []
    for i in range(len(values)):
        start = max(0, i - window_size // 2)
        end = min(len(values), i + window_size // 2)
        smoothed.append(sum(values[start:end]) / (end - start))
    return smoothed

def main():
    if len(sys.argv) < 2:
        print("Please provide a FASTA filename as the first argument.")
        sys.exit(1)
    fasta_file = sys.argv[1]
    description, sequence = read_fasta(fasta_file)
    print("\nAnalyzing sequence:", description or "(no description)")
    analyze_sequence(sequence)
    letters = {'A': sequence.count('A'),
               'T': sequence.count('T'),
               'G': sequence.count('G'),
               'C': sequence.count('C')}
    total = sum(letters.values())
    tm1 = 4 * (letters['G'] + letters['C']) + 2 * (letters['A'] + letters['T'])
    print("\nFirst formula (basic Tm):", tm1)
    gc_fraction = (letters['G'] + letters['C']) / total
    tm2 = 81.5 + 16.6 * math.log10(0.001) + 0.41 * (gc_fraction * 100) - (600 / total)
    print("Second formula (adjusted Tm):", tm2)
    window_size = 8
    results = sliding_window_tm(sequence, window_size)
    print("\nSliding window Tm (first 10 windows):")
    print("Pos\tWindow\t\tTm (°C)")
    for pos, window, tm in results[:10]:
        print(f"{pos}\t{window}\t{tm:.2f}")
    with open("tm_profile.csv", "w") as out:
        out.write("Position,Window,Tm\n")
        for pos, window, tm in results:
            out.write(f"{pos},{window},{tm:.2f}\n")
    print("\nTm profile saved to tm_profile.csv")
    positions = [pos for pos, _, _ in results]
    tm_values = [tm for _, _, tm in results]
    smooth_x = np.linspace(min(positions), max(positions), 2000)
    smooth_y = np.interp(smooth_x, positions, tm_values)
    smooth_y = smooth(smooth_y, window_size=50)
    plt.figure(figsize=(10, 5))
    plt.plot(smooth_x, smooth_y, linewidth=2)
    plt.title("DNA Melting Temperature (Tm) Profile")
    plt.xlabel("Position in sequence")
    plt.ylabel("Tm (°C)")
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    plt.savefig("tm_profile.png", dpi=300)
    print("Tm profile plot saved to tm_profile.png")
    plt.show()

if __name__ == "__main__":
    main()