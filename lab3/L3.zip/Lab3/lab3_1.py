import numpy as np
seq = 'ATTTCGCCGATA'
alphabet = {} 

for letter in seq:
    if (letter in alphabet):
        alphabet[letter] += 1
    else:
        alphabet[letter] = 1

sumGC = 0
sumAT = 0

for i in alphabet:
    if i == "C" or i == "G":
        sumGC += alphabet[i]
    else: sumAT += alphabet[i]

tm = 4 * sumGC + 2 * sumAT
print("First formula:")
print(str(tm) + "°C")

freqGC = (sumGC / len(seq)) * 100
TM = 81.5 + 16.6 * ( np.log10(0.05)) + 0.41 * freqGC - 600/len(seq)
print("Second formula:")
print(str(TM) + "°C")